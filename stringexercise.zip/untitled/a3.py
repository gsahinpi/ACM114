def lsyst(inputsr):
    inputsr=inputsr.upper()
    returnstr=""
    for ch in inputsr:
        if ch=="A":
            returnstr=returnstr+"B"
        elif ch=="B":
            returnstr = returnstr +"AB"
        else:
            returnstr=returnstr+ch
    return returnstr
def createLSystem(numIters,axiom):
    result=lsyst(axiom)
    for i in range(1,numIters):
        result=lsyst(result)

    return result

print(lsyst("Baran"))
print(lsyst(lsyst(lsyst(lsyst("a")))))
print(createLSystem(3,"Baran"))