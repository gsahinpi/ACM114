# write a function that removes all the vowels from a string.
def removevowels(inputstr):
    vowels = "aeiouAEIOU"
    returnstr=""
    for ch in inputstr:
        if ch not in vowels:
            returnstr=returnstr+ch
    return returnstr
print (removevowels("gokcen"))
print (removevowels("tugce"))