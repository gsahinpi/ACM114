import turtle


def applyRules(ch):
    newstr = ""
    if ch == 'F':
        newstr = 'F-F++F-F'   # Rule 1
    else:
        newstr = ch    # no rules apply so keep the character

    return newstr

def setresultstr(inputstr):
    returnstr=""

    for ch in inputstr:
            returnstr=returnstr+applyRules(ch)

    return returnstr
def iterator(inputstr, iteration):
  returnstr=setresultstr(inputstr)
  for i in range(0,iteration):
      returnstr=setresultstr(returnstr)
  return  returnstr
def drawLsystem(aTurtle, instructions, angle, distance):
    for cmd in instructions:
        if cmd == 'F':
            aTurtle.forward(distance)
        elif cmd == 'B':
            aTurtle.backward(distance)
        elif cmd == '+':
            aTurtle.right(angle)
        elif cmd == '-':
            aTurtle.left(angle)


print(iterator("F",4))
t = turtle.Turtle()  # create the turtle
wn = turtle.Screen()
t.up()
t.backward(300)
t.down()
t.speed(20)
drawLsystem(t, iterator("F",4), 60, 5)
wn.exitonclick()