fruit = "apple"
for idx in range(5):
    currentChar = fruit[idx]
    print(currentChar)
for c in fruit:
    print(c)
fruit = "apple"
print(list(range(len(fruit)-1, -1, -2)))
for idx in range(len(fruit)-1, -1, -1):
    print(fruit[idx])