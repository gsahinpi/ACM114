def find(astring, achar):
    ind=-1
    count=0
    for ch in astring:
        if ch==achar:
            ind=count
            break
        count=count+1
    return ind
def find2(astring, achar,start):
    inputstr=astring[start+1:]
    if find(inputstr,achar)==-1:
        return -1
    return find(inputstr,achar)+find(astring,achar)+1

def find3(astring, achar, start):
    """
    Find and return the index of achar in astring.
    Return -1 if achar does not occur in astring.
    """
    ix = start
    found = False
    while ix < len(astring) and not found:
        if astring[ix] == achar:
            found = True
        else:
            ix = ix + 1
    if found:
        return ix
    else:
        return -1

print(find2('banana', 'a', 2))


print(find("ana","a"))
print(find("ana","n"))
print(find("ana","c"))
print(find("and","d"))
print(find2("amca","a",find("ana","a")))
import string
print(string.ascii_lowercase)
print(string.ascii_uppercase)
print(string.digits)
print(string.punctuation)
