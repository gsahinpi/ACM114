import turtle
def chai(size):
    """ mystery! """
    if size<10:
        return
    turtle.forward(size)
    turtle.left(90)
    turtle.forward(size/2.0)
    turtle.right(90)
    chai(size/2)
    turtle.right(90)
    turtle.forward(size)
    turtle.left(90)
    chai(size/2)
    turtle.left(90)
    turtle.forward(size/2.0)
    turtle.right(90)
    turtle.backward(size)

chai(100)
input()

