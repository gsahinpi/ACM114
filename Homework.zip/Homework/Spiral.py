import turtle

def spiral(initialLength, angle, multiplier):
    if initialLength<=1:
        return
    else:
        turtle.forward(initialLength)
        turtle.right(angle)
        spiral(initialLength*multiplier,angle,multiplier)


spiral(200,90,0.75)
spiral(50,90,0.8)

input()

