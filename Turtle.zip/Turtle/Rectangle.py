import turtle

def square():
    turtle.forward(100)
    for i in range (0,3):
        turtle.right(90)
        turtle.forward(100)
square()
input()
