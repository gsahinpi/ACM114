import turtle

turtle.forward(100)
turtle.right(90)
turtle.penup()
turtle.forward(100)
turtle.pendown()
turtle.pencolor("red")
turtle.circle(100)
turtle.pencolor("blue")
turtle.forward(50)
print(turtle.xcor())
print(turtle.ycor())
input()