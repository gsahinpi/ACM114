import turtle

def tri1():

    turtle.forward(100)
    turtle.right(120)
    turtle.forward(100)
    turtle.right(120)
    turtle.forward(100)

def  tri2():
    turtle.pencolor("red")
    turtle.forward(100)
    for i in range(0,2):
        turtle.right(120)
        turtle.forward(100)

tri1()
tri2()
input()
