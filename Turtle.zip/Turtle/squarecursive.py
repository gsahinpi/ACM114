import turtle

def squ(n):
    if n==0:
        return
    else:
        turtle.forward(100)
        turtle.left(90)
        return squ(n-1)

squ(4)
input()