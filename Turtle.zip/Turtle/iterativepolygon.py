import turtle as trt

def itepoli(sides):
    for i in range(0, sides):
        trt.forward(50)
        trt.right(360/sides)
itepoli(6)
x=trt.xcor()
y=trt.ycor()
trt.goto(int(x+50),int (y+50))
itepoli(7)
x=trt.xcor()
y=trt.ycor()
trt.goto(int(x+50),int (y+50))
itepoli(8)

input()
