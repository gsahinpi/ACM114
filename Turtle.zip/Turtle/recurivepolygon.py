import turtle as trt

def recpoli(n,sides):
    if n==0:
       return
    else:
        trt.forward(100)
        trt.right(360/sides)
        return recpoli(n-1,sides)


recpoli(8)