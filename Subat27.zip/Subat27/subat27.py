import random


def faktoriyel():
    product=1
    for i in range(1,4):
        product=product*i
    return product
print (faktoriyel())



def faktoriyel(n):
    product=1
    for i in range(1,n+1):
        product=product*i
    return product
print (faktoriyel(13))

def faktoriyel(n):
    product=1
    for i in range(1,n+1):
        product=product*i
    return product
print (faktoriyel(49)/(faktoriyel(49-6)*faktoriyel(6)))


"""for each dışında range i kullanacaksak  onun range olduğunu hatırlatmamız lazım"""
def gokhanaborc():
    sans=list(range(1,50))
    sansli=list()           #bos liste açıyor
    for i in range(0,6):
        eleman=random.choice(sans)              #aynı elemanı çıkardığım için bazen 6 dan az verecek
        if not (eleman in sansli):
            sansli.append(random.choice(sans))
    return sansli
print(gokhanaborc())



"""her seferinde 6 eleman verecek"""
def gokhanaborc2():
    sans=list(range(1,50))
    sansli=list()
    count=0
    while count<6:
        eleman=random.choice(sans)
        if not (eleman in sansli):
            sansli.append(eleman)
            count=count+1
    return sansli
print(gokhanaborc2())



