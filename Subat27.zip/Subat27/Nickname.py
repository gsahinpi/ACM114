import random
def nick():
    sifat=["kosan", "ziplayan", "uyuyan", "oturan", "islak"]
    isim=["boga", "at", "tahta","kedi", "koala"]
    out1=random.choice(sifat)
    out2=random.choice(isim)
    return out1+" "+out2
while 1:            #infinite loop
    print (nick())
    """ cikmasi icin return yerine break koyuyoruz"""
    answer=input("Enter yes to quit")
    if answer=="yes":
        break




