# CS5 Gold, Lab1 part 2
# Filename: hw1pr2.py
# Name: Elif Sude Gökay
# Problem description: First few functions!

def dbl(x):

    return 2*x
print(dbl(21))

#Problem1
"""Write sq(x), which takes in a number named x as
input. Then, sq should output the square of its
input.
Note that this is the square, not the square root.
(The square is x times itself... .)"""

def sq(y):

    return y*y



#Problem2

def interp(low,hi,fraction):
    low = input('Enter low: ')
    hi = input('Enter high: ')
    fraction = input('Enter fraction: ')
    return  ((hi-low)*fraction) +low


print(interp(interp(24, 42, 0)))
print(interp(102, 117, -4.0))


#Problem 3
"""
Write a function checkends(s), which takes in
a string s and returns True if the first character
in s is the same as the last character in s.
"""

def checkends (s):
    if s[0]==s[-1]:
        return True
    else:
        return False

print(checkends(checkends('no match')))
print(checkends('hah! a match'))
print(checkends('q'))
print(checkends(' '))



#Problem 4

"""Write a function flipside(s), which takes in
a string s and returns a string whose first half
is s's second half and whose second half is s's first
half."""


def flipside(s):
    return s[len(s) / 2:] + s[:len(s) / 2]
print(flipside('homework'))
print(flipside('carpets'))
print(flipside('elif'))


#Problem 5
"""Write convertFromSeconds(s), which takes in
a nonnegative integer number of seconds s and
returns a list (we'll call it L) of four nonnegative
integers that represents that number of seconds in
more conventional units of time, such that:
◦ the initial element represents a number of
days
◦ the next element represents a number of
hours
◦ the next element represents a number of
minutes
◦ the final element represents a number of
seconds"""
def convertFromSeconds(s):


    days  = s // (24 * 3600)
    seconds= s % (24 * 3600)
    hours = s // 3600
    s %= 3600
    minutes = seconds // 60
    s %= 60
    s = seconds
    return {days, hours, minutes, seconds}

