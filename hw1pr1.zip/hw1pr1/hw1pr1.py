# Problem description: First Python lab!
#Name: Elif Sude Gokay

pi = [3,1,4,1,5,9]
e = [2,7,1]

# Example problem (problem 0): [2,7,5,9]
answer0 = e[0:2] + pi[-2:]
print(answer0)


#Problem 1: creating [7,1]
answer1 = e[1:2] + pi[1:2]
print(answer1)

#Problem2: Use pi and/or e to create the list [9,1,1]

answer2 = pi[5:] + 2*e[2:]
print(answer2)
#Problem3: Use pi and/or e to create the list [1,4,1,5,9]
answer3=pi[1:]
print(answer3)

#Problem4: Use pi and/or e to create the list [1,2,3,4,5].

answer4=e[2:] + e[0:1] + pi[0:5:2]
print(answer4)


# Lab1 string practice

#You may use any combination of these four string operations:
#String indexing, e.g., h[0]
#String slicing, e.g., m[1:]
#String concatenation, +, e.g., h + m
#Repetition, *, e.g., 42*c

h = 'harvey'
m = 'mudd'
c = 'college'

#Problem5: Use h, m, and c to create 'hey'.
answer5 = h[0] + h[4:6]
print(answer5)

#Problem6: Create collude
answer6=c[0:4]+m[1:3]+h[4]
print(answer6)

#Problem7: Create arveyudd
answer7=h[1:]+m[1:]
print(answer7)
#Problem8:Create hardeharharhar
answer8=h[0:3]+m[2]+h[4]+3*h[0:3]
print(answer8)
#Problem9:legomyego
answer9=c[3:6]+c[1]+m[0]+h[5]+c[4:6]+c[1]
print(answer9)
#Problem10: Create clearcall
answer10=c[0]+c[3:5]+h[1:3]+c[0]+h[1]+c[2:4]
print(answer10)