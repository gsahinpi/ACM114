def say(n):
    count=0;
    for i in range(0,len(n)):
        if n[i]==" ":
            count=count+1
    return count+1
def kelimeler(n):
    n=n+" "
    start = 0
    kelime=list()
    for i in range(0, len(n)):
        if n[i] == " ":
            kelime.append(n[start:i])
            start=i+1
    return kelime
print(say("Lorem ipsum dolor sit."))
print(kelimeler("Lorem ipsum dolor sit."))
