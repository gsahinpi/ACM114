def recursivefunc(n):
    if n <=1:
        return 1
    return n*recursivefunc(n-1)
print(recursivefunc(5))

'''recursive yazabilmek için hep base rula ihtiyac var'''


def fibonacci(n):
    if n<=1:
        return 1
    return fibonacci(n-1)+fibonacci(n-2)

print(fibonacci(5))

def fact(n):
    product=1
    for i in range (1,n+1):
        product=product*i
    return  product

print(fact(8))

def recfuct(n):
    if n <=1:
        return  1
    return n*recfuct(n-1)
print (recfuct(5))
