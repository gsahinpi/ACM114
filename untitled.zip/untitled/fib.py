def fibit(n):
    prev=1
    preprev=1
    sum=1
    for i in range(2,n+1):
       sum=prev+preprev
       preprev = prev
       prev=sum
    return sum
def fibrec(n):
    if n<=1:
        return  1
    return  fibrec(n-1)+fibrec(n-2)

print(fibit(3))
print(fibit(4))
print(fibit(5))
print("!!!!"+str(fibrec(5)))




