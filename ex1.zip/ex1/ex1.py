"""def burda fonksiyonlar için  keyword"""
def orkun(x) :

        return 2*x
        """2x yazarsan x in türü belli olmayacağı için hata verir"""

"""buraya kadar ekranda bir şey gözükmez"""
print (orkun(7))
berke=3
print(orkun(berke))
berke=orkun(berke)
print(berke)
x=2
print(orkun(x))


